from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        
        # Connection Variables
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30227
        DB = 'AAC'
        COL = 'animals'
        
         # Print statement for debugging
        print(f"Username: {username}, Password: {password}")

        # Initialize MongoDB connection
        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}/?authSource=admin')
        self.database = self.client[DB]
        self.collection = self.database[COL]
        
    # Create method to insert a document
    def create(self, data):
        if data:
            self.collection.insert_one(data)
            return True
        else:
            raise ValueError("Data must not be empty")
            return False

    # Read method to find documents based on criteria
    def read(self, criteria=None):
        if criteria:
            result = list(self.collection.find(criteria))
            return result
        else:
            # If no criteria is provided, return all documents
            result = list(self.collection.find())
            return result

    # Update method to modify existing documents
    def update(self, criteria, update_data):
        if criteria and update_data:
            result = self.collection.update_many(criteria, {"$set": update_data})
            return result.modified_count  # Return the number of modified documents
        else:
            raise ValueError("Criteria and update data must not be empty")

    # Delete method to remove documents
    def delete(self, criteria):
        if criteria:
            result = self.collection.delete_many(criteria)
            return result.deleted_count  # Return the number of deleted documents
        else:
            raise ValueError("Criteria must not be empty")

# Example usage
if __name__ == "__main__":
    shelter = AnimalShelter()

    # Example of inserting a document
    new_data = {"name": "Fluffy", "breed": "Golden Retriever", "outcome_type": "Adoption"}
    insert_result = shelter.create(new_data)
    print(f"Insert was successful: {insert_result}")

    # Example of reading documents
    query_criteria = {"breed": "Golden Retriever"}
    read_result = shelter.read(query_criteria)
    print(f"Query returned: {read_result}")

    # Example of reading all documents (without criteria)
    all_animals = shelter.read()  # No criteria provided
    print(f"All animals in the shelter: {all_animals}")

    # Example of updating documents
    update_criteria = {"name": "Fluffy"}
    update_data = {"outcome_type": "Foster"}
    update_count = shelter.update(update_criteria, update_data)
    print(f"Number of documents updated: {update_count}")

    # Example of deleting documents
    delete_criteria = {"name": "Fluffy"}
    delete_count = shelter.delete(delete_criteria)
    print(f"Number of documents deleted: {delete_count}")
