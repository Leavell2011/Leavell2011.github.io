import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment a = new Appointment("12345", futureDate, "Doctor visit");
        assertEquals("12345", a.getAppointmentId());
        assertEquals("Doctor visit", a.getDescription());
        assertEquals(futureDate, a.getAppointmentDate());
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, "This description is far too long to be valid because it exceeds 50 characters");
        });
    }

    @Test
    public void testPastDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Checkup");
        });
    }
}
