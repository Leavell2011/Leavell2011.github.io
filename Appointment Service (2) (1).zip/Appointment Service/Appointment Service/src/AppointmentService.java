
import java.io.*;
import java.util.*;

public class AppointmentService {
    private Map<String, Appointment> appointments = new HashMap<>();
    private static final String FILE_NAME = "appointments.txt";

    public AppointmentService() {
        loadAppointmentsFromFile();
    }

    public void addAppointment(Appointment appointment) {
        appointments.put(appointment.getAppointmentId(), appointment);
        saveAppointmentsToFile();
    }

    public void deleteAppointment(String appointmentId) {
        appointments.remove(appointmentId);
        saveAppointmentsToFile();
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }

    public List<Appointment> getAllAppointments() {
        return new ArrayList<>(appointments.values());
    }

    public List<Appointment> searchAppointments(String keyword) {
        List<Appointment> results = new ArrayList<>();
        for (Appointment a : appointments.values()) {
            if (a.getDescription().toLowerCase().contains(keyword.toLowerCase())) {
                results.add(a);
            }
        }
        return results;
    }

    public String updateAppointment(String appointmentId, Date newDate, String newDescription) {
        Appointment a = appointments.get(appointmentId);
        if (a == null) {
            return "Appointment not found";
        }
        try {
            a.setAppointmentDate(newDate);
            a.setDescription(newDescription);
            saveAppointmentsToFile();
            return "Appointment updated successfully";
        } catch (IllegalArgumentException e) {
            return e.getMessage();
        }
    }

    private void saveAppointmentsToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (Appointment a : appointments.values()) {
                writer.println(a.getAppointmentId() + "|" + a.getAppointmentDate().getTime() + "|" + a.getDescription());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadAppointmentsFromFile() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split("\\|");
                if (parts.length == 3) {
                    String id = parts[0];
                    Date date = new Date(Long.parseLong(parts[1]));
                    String desc = parts[2];
                    appointments.put(id, new Appointment(id, date, desc));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
