import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
    private AppointmentService service;

    @BeforeEach
    public void setup() {
        service = new AppointmentService();
    }

    @Test
    public void testAddAndGetAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment a = new Appointment("test1", futureDate, "Checkup");
        service.addAppointment(a);

        Appointment found = service.getAppointment("test1");
        assertNotNull(found);
        assertEquals("Checkup", found.getDescription());
    }

    @Test
    public void testUpdateAppointment() {
        Date date = new Date(System.currentTimeMillis() + 100000);
        Appointment a = new Appointment("edit1", date, "Old description");
        service.addAppointment(a);

        Date newDate = new Date(System.currentTimeMillis() + 200000);
        String result = service.updateAppointment("edit1", newDate, "New description");
        assertEquals("Appointment updated successfully", result);
        Appointment updated = service.getAppointment("edit1");
        assertEquals("New description", updated.getDescription());
    }

    @Test
    public void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment a = new Appointment("delete1", futureDate, "To be deleted");
        service.addAppointment(a);
        service.deleteAppointment("delete1");

        assertNull(service.getAppointment("delete1"));
    }
}
