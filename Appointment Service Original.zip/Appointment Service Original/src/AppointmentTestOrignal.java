import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {
    @Test
    public void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000); // 10 seconds in the future
        Appointment appointment = new Appointment("1234567890", futureDate, "Valid description");
        
        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Valid description", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000); // 10 seconds in the future
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Valid description");
        });
    }

    @Test
    public void testInvalidAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 10000); // 10 seconds in the past
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", pastDate, "Valid description");
        });
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000); // 10 seconds in the future
        String longDescription = repeat("A", 51); // 51 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, longDescription);
        });
    }

    // Custom repeat method
    private String repeat(String str, int times) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < times; i++) {
            builder.append(str);
        }
        return builder.toString();
    }
}