import java.util.*;

// The ContactService class provides functionalities to manage contacts
// using a HashMap for efficient access and search operations.
public class ContactService {
    // Stores contacts with their unique ID as the key for O(1) lookup
    private Map<String, Contact> contactMap = new HashMap<>();

    // Adds a contact to the service
    public void addContact(Contact contact) {
        contactMap.put(contact.getId(), contact);
    }

    // Retrieves a contact by its ID in constant time
    public Contact getContact(String contactId) {
        return contactMap.get(contactId);
    }

    // Deletes a contact by ID and returns true if deletion was successful
    public boolean deleteContact(String contactId) {
        return contactMap.remove(contactId) != null;
    }

    // Updates the fields of an existing contact by ID
    public boolean updateContact(String contactId, String firstName, String lastName, String phoneNumber) {
        Contact contact = contactMap.get(contactId);
        if (contact != null) {
            contact.setFirstName(firstName);
            contact.setLastName(lastName);
            contact.setPhoneNumber(phoneNumber);
            return true;
        }
        return false;
    }

    // Returns a list of contacts whose first name starts with the given prefix
    public List<Contact> autocompleteSearch(String prefix) {
        List<Contact> results = new ArrayList<>();
        for (Contact contact : contactMap.values()) {
            if (contact.getFirstName().startsWith(prefix)) {
                results.add(contact);
            }
        }
        return results;
    }
}
