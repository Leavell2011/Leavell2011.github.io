import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import static org.junit.jupiter.api.Assertions.*;

// Unit tests for ContactService
public class ContactServiceTest {
    private ContactService service;

    // Set up a new instance before each test
    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    // Test adding a contact and retrieving it by ID
    @Test
    public void testAddAndGetContact() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890");
        service.addContact(contact);
        assertEquals(contact, service.getContact("1"));
    }

    // Test deleting a contact and verifying it's removed
    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("2", "Jane", "Smith", "2345678901");
        service.addContact(contact);
        assertTrue(service.deleteContact("2"));
        assertNull(service.getContact("2"));
    }

    // Test updating an existing contact's details
    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("3", "Sam", "Green", "3456789012");
        service.addContact(contact);
        assertTrue(service.updateContact("3", "Samuel", "Greene", "9876543210"));
        Contact updated = service.getContact("3");
        assertEquals("Samuel", updated.getFirstName());
        assertEquals("Greene", updated.getLastName());
        assertEquals("9876543210", updated.getPhoneNumber());
    }

    // Test autocomplete functionality with prefix matching
    @Test
    public void testAutocompleteSearch() {
        Contact contact1 = new Contact("1", "Alice", "Smith", "1234567890");
        Contact contact2 = new Contact("2", "Alicia", "Jones", "2345678901");
        Contact contact3 = new Contact("3", "Bob", "Taylor", "3456789012");
        service.addContact(contact1);
        service.addContact(contact2);
        service.addContact(contact3);

        List<Contact> results = service.autocompleteSearch("Ali");
        assertEquals(2, results.size());
        assertTrue(results.contains(contact1));
        assertTrue(results.contains(contact2));
    }
}
