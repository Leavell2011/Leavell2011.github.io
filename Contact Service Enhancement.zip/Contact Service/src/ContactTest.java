import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

// Unit tests for the Contact class
public class ContactTest {
    // Test the constructor and getter methods
    @Test
    public void testContactConstructorAndGetters() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890");
        assertEquals("1", contact.getId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhoneNumber());
    }

    // Test the setter methods to update contact fields
    @Test
    public void testSetters() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890");
        contact.setFirstName("Jane");
        contact.setLastName("Smith");
        contact.setPhoneNumber("0987654321");

        assertEquals("Jane", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("0987654321", contact.getPhoneNumber());
    }
}
