const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();

const PORT = process.env.PORT || 5000;
const MONGO_URI = 'mongodb://localhost:27017/AAC';
const JWT_SECRET = 'your_jwt_secret_key';

mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const animalSchema = new mongoose.Schema({
  name: String,
  breed: String,
  age_upon_outcome: String,
  outcome_type: String,
  sex_upon_outcome: String,
  location: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: [Number]
  }
});
animalSchema.index({ location: '2dsphere' });
const Animal = mongoose.model('Animal', animalSchema);

app.use(cors());
app.use(bodyParser.json());

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

function authorizeRole(role) {
  return (req, res, next) => {
    if (req.user.role !== role) return res.sendStatus(403);
    next();
  };
}

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'admin' && password === 'password') {
    const token = jwt.sign({ username, role: 'admin' }, JWT_SECRET);
    return res.json({ token });
  } else if (username === 'viewer' && password === 'password') {
    const token = jwt.sign({ username, role: 'viewer' }, JWT_SECRET);
    return res.json({ token });
  }
  res.status(401).send('Invalid credentials');
});

app.get('/api/animals', async (req, res) => {
  try {
    const animals = await Animal.find();
    res.json(animals);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/animals', authenticateToken, async (req, res) => {
  try {
    const newAnimal = new Animal(req.body);
    const result = await newAnimal.save();
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/animals/:id', authenticateToken, authorizeRole('admin'), async (req, res) => {
  try {
    const result = await Animal.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!result) return res.status(404).json({ message: "Animal not found" });
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/animals/:id', authenticateToken, authorizeRole('admin'), async (req, res) => {
  try {
    const result = await Animal.findByIdAndDelete(req.params.id);
    if (!result) return res.status(404).json({ message: "Animal not found" });
    res.json({ message: "Deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/analytics/popular-breeds', async (req, res) => {
  try {
    const result = await Animal.aggregate([
      { $group: { _id: "$breed", count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 }
    ]);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/animals/near', async (req, res) => {
  const { longitude, latitude, maxDistance } = req.body;
  try {
    const animals = await Animal.find({
      location: {
        $nearSphere: {
          $geometry: { type: "Point", coordinates: [longitude, latitude] },
          $maxDistance: maxDistance
        }
      }
    });
    res.json(animals);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
