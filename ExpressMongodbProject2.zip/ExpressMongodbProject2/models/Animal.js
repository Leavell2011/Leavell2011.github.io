const mongoose = require('mongoose');

const animalSchema = new mongoose.Schema({
  name: String,
  breed: String,
  age_upon_outcome: String,
  outcome_type: String,
  sex_upon_outcome: String,
  location: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: [Number]
  }
});

animalSchema.index({ location: '2dsphere' });

module.exports = mongoose.model('Animal', animalSchema);
